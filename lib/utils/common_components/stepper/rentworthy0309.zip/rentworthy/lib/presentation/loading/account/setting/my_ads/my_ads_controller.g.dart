// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'my_ads_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$myAdsControllerHash() => r'ea2f2575831c4f1464125e2fa2746ece503fd1bd';

/// See also [MyAdsController].
@ProviderFor(MyAdsController)
final myAdsControllerProvider =
    AutoDisposeAsyncNotifierProvider<MyAdsController, void>.internal(
  MyAdsController.new,
  name: r'myAdsControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$myAdsControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MyAdsController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
