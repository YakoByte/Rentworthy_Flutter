// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$chatScreenControllerHash() =>
    r'16a39d955657c385e1a1b58323bed174d27a260c';

/// See also [ChatScreenController].
@ProviderFor(ChatScreenController)
final chatScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<ChatScreenController, void>.internal(
  ChatScreenController.new,
  name: r'chatScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$chatScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ChatScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
