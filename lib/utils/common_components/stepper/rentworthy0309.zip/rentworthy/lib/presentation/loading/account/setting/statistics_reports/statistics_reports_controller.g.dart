// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'statistics_reports_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$statisticsReportsControllerHash() =>
    r'200167c861bd35ea7285ded1cc13735a689374bd';

/// See also [StatisticsReportsController].
@ProviderFor(StatisticsReportsController)
final statisticsReportsControllerProvider = AutoDisposeAsyncNotifierProvider<
    StatisticsReportsController, void>.internal(
  StatisticsReportsController.new,
  name: r'statisticsReportsControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$statisticsReportsControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$StatisticsReportsController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
