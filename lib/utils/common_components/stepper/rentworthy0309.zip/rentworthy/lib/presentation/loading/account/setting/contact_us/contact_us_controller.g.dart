// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contact_us_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$contactUsControllerHash() =>
    r'23d5dee4b0fb29173b8c348a71139fe66f2fa9a8';

/// See also [ContactUsController].
@ProviderFor(ContactUsController)
final contactUsControllerProvider =
    AutoDisposeAsyncNotifierProvider<ContactUsController, void>.internal(
  ContactUsController.new,
  name: r'contactUsControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$contactUsControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ContactUsController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
