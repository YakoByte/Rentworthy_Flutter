// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_phone_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$loginPhoneScreenControllerHash() =>
    r'6e972c481305cc0ed925bc9be5a6938063cd0cd2';

/// See also [LoginPhoneScreenController].
@ProviderFor(LoginPhoneScreenController)
final loginPhoneScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<LoginPhoneScreenController, void>.internal(
  LoginPhoneScreenController.new,
  name: r'loginPhoneScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$loginPhoneScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$LoginPhoneScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
