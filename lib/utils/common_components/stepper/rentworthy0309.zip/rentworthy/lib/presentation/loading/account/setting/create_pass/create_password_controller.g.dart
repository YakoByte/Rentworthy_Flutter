// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'create_password_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$createPasswordControllerHash() =>
    r'260b6e0d3b583a82588791455d4b61b437738e02';

/// See also [CreatePasswordController].
@ProviderFor(CreatePasswordController)
final createPasswordControllerProvider =
    AutoDisposeAsyncNotifierProvider<CreatePasswordController, void>.internal(
  CreatePasswordController.new,
  name: r'createPasswordControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$createPasswordControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CreatePasswordController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
