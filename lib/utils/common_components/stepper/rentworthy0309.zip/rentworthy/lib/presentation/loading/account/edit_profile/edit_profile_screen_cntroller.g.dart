// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'edit_profile_screen_cntroller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$editProfileControllerHash() =>
    r'6e4d3023d52f51c92de855ab431dea4161766fcf';

/// See also [EditProfileController].
@ProviderFor(EditProfileController)
final editProfileControllerProvider =
    AutoDisposeAsyncNotifierProvider<EditProfileController, void>.internal(
  EditProfileController.new,
  name: r'editProfileControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$editProfileControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EditProfileController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
