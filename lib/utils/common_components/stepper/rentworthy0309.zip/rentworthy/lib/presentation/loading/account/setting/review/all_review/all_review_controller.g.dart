// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'all_review_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$allReviewControllerHash() =>
    r'd80a75dbc6617f276426c43726e3c1c2c48cee83';

/// See also [AllReviewController].
@ProviderFor(AllReviewController)
final allReviewControllerProvider =
    AutoDisposeAsyncNotifierProvider<AllReviewController, void>.internal(
  AllReviewController.new,
  name: r'allReviewControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$allReviewControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AllReviewController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
