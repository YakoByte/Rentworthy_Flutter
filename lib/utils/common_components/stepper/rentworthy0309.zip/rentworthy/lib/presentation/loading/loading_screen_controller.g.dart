// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'loading_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$loadingScreenControllerHash() =>
    r'cec523fbf4feb40fb854c1ac3e32fea574769a03';

/// See also [LoadingScreenController].
@ProviderFor(LoadingScreenController)
final loadingScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<LoadingScreenController, void>.internal(
  LoadingScreenController.new,
  name: r'loadingScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$loadingScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$LoadingScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
