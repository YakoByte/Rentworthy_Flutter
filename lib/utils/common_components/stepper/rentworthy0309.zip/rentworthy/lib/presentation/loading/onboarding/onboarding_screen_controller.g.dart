// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'onboarding_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$onBoardingScreenControllerHash() =>
    r'5d3ee2cfa232ce27802d3faaed9220d7c10f285a';

/// See also [OnBoardingScreenController].
@ProviderFor(OnBoardingScreenController)
final onBoardingScreenControllerProvider = AutoDisposeAsyncNotifierProvider<
    OnBoardingScreenController, OnBoardingScreenState>.internal(
  OnBoardingScreenController.new,
  name: r'onBoardingScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$onBoardingScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OnBoardingScreenController
    = AutoDisposeAsyncNotifier<OnBoardingScreenState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
