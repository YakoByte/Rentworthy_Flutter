// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'rent_now_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$rentNowControllerHash() => r'8b794d750b546387c651fb0a03381424ee126f5a';

/// See also [RentNowController].
@ProviderFor(RentNowController)
final rentNowControllerProvider =
    AutoDisposeAsyncNotifierProvider<RentNowController, void>.internal(
  RentNowController.new,
  name: r'rentNowControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$rentNowControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RentNowController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
