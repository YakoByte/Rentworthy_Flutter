// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'booking_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$bookingScreenControllerHash() =>
    r'59867d1cae2361cce46381a0de30365b56bfc600';

/// See also [BookingScreenController].
@ProviderFor(BookingScreenController)
final bookingScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<BookingScreenController, void>.internal(
  BookingScreenController.new,
  name: r'bookingScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$bookingScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$BookingScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
