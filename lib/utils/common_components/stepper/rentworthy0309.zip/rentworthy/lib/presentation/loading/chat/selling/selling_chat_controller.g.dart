// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'selling_chat_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$sellingChatControllerHash() =>
    r'74ddba0ea954f8a9f5e8e42e04edb16dfb17b516';

/// See also [SellingChatController].
@ProviderFor(SellingChatController)
final sellingChatControllerProvider =
    AutoDisposeAsyncNotifierProvider<SellingChatController, void>.internal(
  SellingChatController.new,
  name: r'sellingChatControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$sellingChatControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SellingChatController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
