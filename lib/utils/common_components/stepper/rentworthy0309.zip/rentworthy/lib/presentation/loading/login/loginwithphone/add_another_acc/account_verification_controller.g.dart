// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account_verification_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$accountVerificationControllerHash() =>
    r'e699921ff8a7e8e117d377b94e7b41a6054d0810';

/// See also [AccountVerificationController].
@ProviderFor(AccountVerificationController)
final accountVerificationControllerProvider = AutoDisposeAsyncNotifierProvider<
    AccountVerificationController, AccountVerificationState>.internal(
  AccountVerificationController.new,
  name: r'accountVerificationControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$accountVerificationControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AccountVerificationController
    = AutoDisposeAsyncNotifier<AccountVerificationState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
