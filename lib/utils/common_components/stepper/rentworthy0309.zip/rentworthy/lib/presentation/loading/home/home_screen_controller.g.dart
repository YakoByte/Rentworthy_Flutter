// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'home_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$homeScreenControllerHash() =>
    r'86a3bb91ebcfb5782bd22f64fcf4432d18ffd866';

/// See also [HomeScreenController].
@ProviderFor(HomeScreenController)
final homeScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<HomeScreenController, void>.internal(
  HomeScreenController.new,
  name: r'homeScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$homeScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$HomeScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
