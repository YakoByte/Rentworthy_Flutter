// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category_details_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$categoryDetailsControllerHash() =>
    r'842e56e4fbad5cf4d75699d0696f35b4579f17b7';

/// See also [CategoryDetailsController].
@ProviderFor(CategoryDetailsController)
final categoryDetailsControllerProvider =
    AutoDisposeAsyncNotifierProvider<CategoryDetailsController, void>.internal(
  CategoryDetailsController.new,
  name: r'categoryDetailsControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$categoryDetailsControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CategoryDetailsController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
