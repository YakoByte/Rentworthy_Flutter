// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_address_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addAddressControllerHash() =>
    r'8f6dfd4c0eee0d9a111e614a2e07cc1faab5bcd0';

/// See also [AddAddressController].
@ProviderFor(AddAddressController)
final addAddressControllerProvider =
    AutoDisposeAsyncNotifierProvider<AddAddressController, void>.internal(
  AddAddressController.new,
  name: r'addAddressControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addAddressControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddAddressController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
