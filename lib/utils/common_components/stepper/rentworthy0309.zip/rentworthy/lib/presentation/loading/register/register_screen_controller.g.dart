// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'register_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$registerScreenControllerHash() =>
    r'02ee39318b2ac0497e9a28bc626d94f7b5dc2d5e';

/// See also [RegisterScreenController].
@ProviderFor(RegisterScreenController)
final registerScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<RegisterScreenController, void>.internal(
  RegisterScreenController.new,
  name: r'registerScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$registerScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RegisterScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
