// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_availablity_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$productAvailabilityControllerHash() =>
    r'4b147195b6d37defecddafabb74274a4903693a0';

/// See also [ProductAvailabilityController].
@ProviderFor(ProductAvailabilityController)
final productAvailabilityControllerProvider = AutoDisposeAsyncNotifierProvider<
    ProductAvailabilityController, void>.internal(
  ProductAvailabilityController.new,
  name: r'productAvailabilityControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$productAvailabilityControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ProductAvailabilityController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
