// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sell_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$sellScreenControllerHash() =>
    r'520f9afea4cb49bfe36240c0b730bc6266e73fa6';

/// See also [SellScreenController].
@ProviderFor(SellScreenController)
final sellScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<SellScreenController, void>.internal(
  SellScreenController.new,
  name: r'sellScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$sellScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SellScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
