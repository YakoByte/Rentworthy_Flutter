// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'select_lang_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$selectLanControllerHash() =>
    r'f96e08d70704238a69e5e8827874cce3d62bcc71';

/// See also [SelectLanController].
@ProviderFor(SelectLanController)
final selectLanControllerProvider =
    AutoDisposeAsyncNotifierProvider<SelectLanController, void>.internal(
  SelectLanController.new,
  name: r'selectLanControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$selectLanControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SelectLanController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
