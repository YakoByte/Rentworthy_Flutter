// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'unread_chat_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$unreadChatControllerHash() =>
    r'e58a61a208316cefa560f36724966c3685ab6ed7';

/// See also [UnreadChatController].
@ProviderFor(UnreadChatController)
final unreadChatControllerProvider =
    AutoDisposeAsyncNotifierProvider<UnreadChatController, void>.internal(
  UnreadChatController.new,
  name: r'unreadChatControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$unreadChatControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$UnreadChatController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
