// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'id_verification_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$idVerificationControllerHash() =>
    r'6877caf5434b6921763ddfa8341fa73eefbe5e6f';

/// See also [IdVerificationController].
@ProviderFor(IdVerificationController)
final idVerificationControllerProvider =
    AutoDisposeAsyncNotifierProvider<IdVerificationController, void>.internal(
  IdVerificationController.new,
  name: r'idVerificationControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$idVerificationControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$IdVerificationController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
