// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'all_chat_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$allChatControllerHash() => r'2eb23437e5518c945c44d7b6d309e555e7304c69';

/// See also [AllChatController].
@ProviderFor(AllChatController)
final allChatControllerProvider =
    AutoDisposeAsyncNotifierProvider<AllChatController, void>.internal(
  AllChatController.new,
  name: r'allChatControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$allChatControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AllChatController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
