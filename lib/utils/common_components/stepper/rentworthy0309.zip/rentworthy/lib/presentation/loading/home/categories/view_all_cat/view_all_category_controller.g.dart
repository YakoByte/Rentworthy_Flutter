// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_all_category_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$viewAllCategoryControllerHash() =>
    r'94e807e1b38b260b6624e085dc5b523aa30fb57b';

/// See also [ViewAllCategoryController].
@ProviderFor(ViewAllCategoryController)
final viewAllCategoryControllerProvider =
    AutoDisposeAsyncNotifierProvider<ViewAllCategoryController, void>.internal(
  ViewAllCategoryController.new,
  name: r'viewAllCategoryControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$viewAllCategoryControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ViewAllCategoryController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
