// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'find_location_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$findLocationControllerHash() =>
    r'6d50579ac9eda03aa4a332e6c54bcc536135fb55';

/// See also [FindLocationController].
@ProviderFor(FindLocationController)
final findLocationControllerProvider =
    AutoDisposeAsyncNotifierProvider<FindLocationController, void>.internal(
  FindLocationController.new,
  name: r'findLocationControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$findLocationControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$FindLocationController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
