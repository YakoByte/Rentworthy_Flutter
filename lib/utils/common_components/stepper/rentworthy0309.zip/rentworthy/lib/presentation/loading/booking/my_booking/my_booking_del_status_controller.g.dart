// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'my_booking_del_status_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$myBookingDelStatusControllerHash() =>
    r'fab2a866a386794349ffd4ea21bb514ccb72d0c6';

/// See also [MyBookingDelStatusController].
@ProviderFor(MyBookingDelStatusController)
final myBookingDelStatusControllerProvider = AutoDisposeAsyncNotifierProvider<
    MyBookingDelStatusController, void>.internal(
  MyBookingDelStatusController.new,
  name: r'myBookingDelStatusControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$myBookingDelStatusControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MyBookingDelStatusController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
