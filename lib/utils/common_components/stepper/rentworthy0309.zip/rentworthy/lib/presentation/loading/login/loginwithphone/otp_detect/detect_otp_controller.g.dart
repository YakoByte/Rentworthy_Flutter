// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'detect_otp_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$detectOtpControllerHash() =>
    r'abf588e22e5a80646118e927a847f09b3ed74afb';

/// See also [DetectOtpController].
@ProviderFor(DetectOtpController)
final detectOtpControllerProvider = AutoDisposeAsyncNotifierProvider<
    DetectOtpController, DetectOtpState>.internal(
  DetectOtpController.new,
  name: r'detectOtpControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$detectOtpControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DetectOtpController = AutoDisposeAsyncNotifier<DetectOtpState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
