// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'post_ur_ad_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$postUrAdsControllerHash() =>
    r'4a59de7253ac70d5189c969253f24b054a5234d1';

/// See also [PostUrAdsController].
@ProviderFor(PostUrAdsController)
final postUrAdsControllerProvider =
    AutoDisposeAsyncNotifierProvider<PostUrAdsController, void>.internal(
  PostUrAdsController.new,
  name: r'postUrAdsControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$postUrAdsControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PostUrAdsController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member
