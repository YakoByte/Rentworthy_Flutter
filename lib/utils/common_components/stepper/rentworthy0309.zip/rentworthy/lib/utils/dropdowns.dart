import 'package:dio/dio.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';

class UserModel {
  final String id;
  final DateTime createdAt;
  final String name;
  final String avatar;

  UserModel({
    required this.id,
    required this.createdAt,
    required this.name,
    required this.avatar,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json["id"],
      createdAt: DateTime.parse(json["createdAt"]),
      name: json["name"],
      avatar: json["avatar"],
    );
  }

  static List<UserModel> fromJsonList(List list) {
    return list.map((item) => UserModel.fromJson(item)).toList();
  }

  ///this method will prevent the override of toString
  String userAsString() {
    return '#${this.id} ${this.name}';
  }

  ///this method will prevent the override of toString
  bool userFilterByCreationDate(String filter) {
    return this.createdAt.toString().contains(filter);
  }

  ///custom comparing function to check if two users are equal
  bool isEqual(UserModel model) {
    return this.id == model.id;
  }

  @override
  String toString() => name;
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final _formKey = GlobalKey<FormState>();
  final _openDropDownProgKey = GlobalKey<DropdownSearchState<int>>();
  final _multiKey = GlobalKey<DropdownSearchState<String>>();
  final _popupBuilderKey = GlobalKey<DropdownSearchState<String>>();
  final _popupCustomValidationKey = GlobalKey<DropdownSearchState<int>>();
  final _userEditTextController = TextEditingController(text: 'Mrs');
  final myKey = GlobalKey<DropdownSearchState<MultiLevelString>>();
  final List<MultiLevelString> myItems = [
    MultiLevelString(level1: "1"),
    MultiLevelString(level1: "2"),
    MultiLevelString(
      level1: "3",
      subLevel: [
        MultiLevelString(level1: "sub3-1"),
        MultiLevelString(level1: "sub3-2"),
      ],
    ),
    MultiLevelString(level1: "4")
  ];
  bool? _popupBuilderSelection = false;

  @override
  Widget build(BuildContext context) {
    void _handleCheckBoxState({bool updateState = true}) {
      var selectedItem =
          _popupBuilderKey.currentState?.popupGetSelectedItems ?? [];
      var isAllSelected =
          _popupBuilderKey.currentState?.popupIsAllItemSelected ?? false;
      _popupBuilderSelection =
      selectedItem.isEmpty ? false : (isAllSelected ? true : null);

      if (updateState) setState(() {});
    }

    _handleCheckBoxState(updateState: false);

    return Scaffold(
      appBar: AppBar(title: Text("DropdownSearch Demo")),
      body: Padding(
        padding: const EdgeInsets.all(25),
        child: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: ListView(
            padding: EdgeInsets.all(4),
            children: <Widget>[

              ///************************[simple examples for single and multi selection]************///
              Text("[simple examples for single and multi selection]"),
              Divider(),
              Row(
                children: [
                  Expanded(
                    child: DropdownSearch<int>(
                      items: [1, 2, 3, 4, 5, 6, 7],
                    ),
                  ),
                  Padding(padding: EdgeInsets.all(4)),
                  Expanded(
                    child: DropdownSearch<int>.multiSelection(
                      clearButtonProps: ClearButtonProps(isVisible: true),
                      items: [1, 2, 3, 4, 5, 6, 7],
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _customDropDownExampleMultiSelection(BuildContext context,
      List<UserModel> selectedItems) {
    if (selectedItems.isEmpty) {
      return ListTile(
        contentPadding: EdgeInsets.all(0),
        leading: CircleAvatar(),
        title: Text("No item selected"),
      );
    }

    return Wrap(
      children: selectedItems.map((e) {
        return Padding(
          padding: const EdgeInsets.all(4.0),
          child: Container(
            child: ListTile(
              contentPadding: EdgeInsets.all(0),
              leading: CircleAvatar(
                backgroundImage: NetworkImage(e.avatar),
              ),
              title: Text(e.name),
              subtitle: Text(
                e.createdAt.toString(),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _customPopupItemBuilderExample2(BuildContext context, UserModel item,
      bool isSelected) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8),
      decoration: !isSelected
          ? null
          : BoxDecoration(
        border: Border.all(color: Theme
            .of(context)
            .primaryColor),
        borderRadius: BorderRadius.circular(5),
        color: Colors.white,
      ),
      child: ListTile(
        selected: isSelected,
        title: Text(item.name),
        subtitle: Text(item.createdAt.toString()),
        leading: CircleAvatar(
          backgroundImage: NetworkImage(item.avatar),
        ),
      ),
    );
  }

  Future<List<UserModel>> getData(filter) async {
    var response = await Dio().get(
      "https://63c1210999c0a15d28e1ec1d.mockapi.io/users",
      queryParameters: {"filter": filter},
    );

    final data = response.data;
    if (data != null) {
      return UserModel.fromJsonList(data);
    }

    return [];
  }
}

class _CheckBoxWidget extends StatefulWidget {
  final Widget child;
  final bool? isSelected;
  final ValueChanged<bool?>? onChanged;

  _CheckBoxWidget({required this.child, this.isSelected, this.onChanged});

  @override
  CheckBoxState createState() => CheckBoxState();
}

class CheckBoxState extends State<_CheckBoxWidget> {
  bool? isSelected;

  @override
  void initState() {
    super.initState();
    isSelected = widget.isSelected;
  }

  @override
  void didUpdateWidget(covariant _CheckBoxWidget oldWidget) {
    if (widget.isSelected != isSelected) isSelected = widget.isSelected;
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            Color(0x88F44336),
            Colors.blue,
          ],
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text('Select: '),
              Checkbox(
                  value: isSelected,
                  tristate: true,
                  onChanged: (bool? v) {
                    if (v == null) v = false;
                    setState(() {
                      isSelected = v;
                      if (widget.onChanged != null) widget.onChanged!(v);
                    });
                  }),
            ],
          ),
          Expanded(child: widget.child),
        ],
      ),
    );
  }
}

class MultiLevelString {
  final String level1;
  final List<MultiLevelString> subLevel;
  bool isExpanded;

  MultiLevelString({
    this.level1 = "",
    this.subLevel = const [],
    this.isExpanded = false,
  });

  MultiLevelString copy({
    String? level1,
    List<MultiLevelString>? subLevel,
    bool? isExpanded,
  }) =>
      MultiLevelString(
        level1: level1 ?? this.level1,
        subLevel: subLevel ?? this.subLevel,
        isExpanded: isExpanded ?? this.isExpanded,
      );

  @override
  String toString() => level1;
}
//import 'package:dropdown_search/dropdown_search.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
//
// import '../color.dart';
// import 'common_text.dart';
//
// class CommonDropdown extends ConsumerWidget {
//   void Function(String?)? onChanged;
//   void Function()? onTap;
//   int elevation;
//
//   final bool? messagetext;
//
//   final List<String>? dropdownValue;
//   final String? titleText;
//
//   bool? isDense;
//   double? itemHeight;
//   bool isExpanded;
//   bool autofocus;
//   bool enableFeedback;
//   FocusNode? focusNode;
//   Widget? dropdownicon;
//   Widget? dropdownsuffix;
//
//   double? iconSize;
//   double? menuMaxHeight;
//   Color? focusColor;
//   Color? dropdownColor;
//   Color? iconcolor;
//   Color? icondisablecolor;
//
//   double containerwidth;
//   double containerheight;
//
//   Color? containercolor;
//
//   TextStyle? textstyle;
//   TextStyle? titletextstyle;
//   Widget? dropdowntitle;
//   List<String>? itemslist;
//   AlignmentGeometry? alignment;
//   BorderRadius? borderRadius;
//   EdgeInsetsGeometry? padding;
//   Widget? prefix;
//   String? titlesuffix;
//   BoxBorder? border;
//   bool? checkboxval;
//   void Function(bool)? onchange;
//
//   ///
//   void Function(List<String>?)? onSaved;
//   String? Function(List<String>?)? validator;
//   AutovalidateMode? autoValidateMode = AutovalidateMode.disabled;
//   void Function(List<String>?) onChangedsearch;
//   List<String> items;
//
//   List<String>? selectedItems;
//   Future<List<String>> Function(String)? asyncItems;
//   Widget Function(BuildContext, String?)? dropdownBuilder;
//   DropDownDecoratorProps dropdownDecoratorProps = DropDownDecoratorProps();
//   ClearButtonProps clearButtonProps = ClearButtonProps();
//   DropdownButtonProps dropdownButtonProps = DropdownButtonProps();
//   bool enabled = true;
//   bool Function(String, String)? filterFn;
//   String Function(String)? itemAsString;
//   bool Function(String, String)? compareFn;
//   Future<bool?> Function(List<String>, List<String>)? onBeforeChange;
//   Future<bool?> Function(List<String>)? onBeforePopupOpening;
//   PopupProps<String>? popupProps;
//
//   CommonDropdown({
//     Key? key,
//     this.onSaved,
//     this.validator,
//     this.autoValidateMode,
//     required this.onChangedsearch,
//     required this.items,
//     this.selectedItems,
//     this.asyncItems,
//     this.dropdownBuilder,
//     required this.dropdownDecoratorProps,
//     required this.clearButtonProps,
//     required this.dropdownButtonProps,
//     required this.enabled,
//     this.filterFn,
//     this.dropdownsuffix,
//     this.itemAsString,
//     this.compareFn,
//     this.onBeforeChange,
//     this.onBeforePopupOpening,
//     this.popupProps,
//     this.titlesuffix,
//     this.onChanged,
//     this.onTap,
//     this.dropdowntitle,
//     this.border,
//     this.checkboxval,
//     required this.elevation,
//     this.itemHeight,
//     this.focusNode,
//     this.onchange,
//     this.menuMaxHeight,
//     this.enableFeedback = false,
//     required this.isExpanded,
//     this.autofocus = false,
//     this.itemslist,
//     this.messagetext,
//     this.dropdownValue,
//     this.focusColor,
//     this.dropdownColor,
//     this.borderRadius,
//     this.alignment,
//     this.padding,
//     this.iconcolor,
//     this.isDense,
//     this.icondisablecolor,
//     this.dropdownicon,
//     required this.containerwidth,
//     required this.containerheight,
//     required this.containercolor,
//     this.titleText,
//     this.textstyle,
//     this.titletextstyle,
//     this.iconSize,
//     this.prefix,
//   });
//
//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final height = MediaQuery.of(context).size.height;
//     final width = MediaQuery.of(context).size.width;
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: <Widget>[
//         Container(
//           width: containerwidth,
//           height: containerheight ?? height * 0.06,
//           decoration: BoxDecoration(
//             color: containercolor,
//             border: border,
//             borderRadius: borderRadius,
//           ),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               Expanded(
//                 child: Container(
//                   width: containerwidth,
//                   height: containerheight,
//                   color: containercolor,
//                   child: DropdownSearch<String>.multiSelection(
//                   selectedItems: selectedItems!?? dropdownValue!,
//     onSaved: onSaved,
//                     validator: validator,
//                     autoValidateMode: autoValidateMode,
//                     onChanged: onChangedsearch,
//                     items: items,
//
//                     asyncItems: asyncItems,
//                     dropdownBuilder: _style,
//                     dropdownDecoratorProps: dropdownDecoratorProps,
//                     clearButtonProps: clearButtonProps,
//                     dropdownButtonProps: dropdownButtonProps,
//                     enabled: enabled,
//                     filterFn: filterFn,
//                     itemAsString: itemAsString,
//                     compareFn: compareFn,
//                     onBeforeChange: onBeforeChange,
//                     onBeforePopupOpening: onBeforePopupOpening!,
//                     // popupProps: PopupProps.menu(
//                     //   fit: FlexFit.loose,
//                     //   title: dropdowntitle,
//                     //   containerBuilder: (context, child) {
//                     //     return Container(
//                     //       color: containercolor,
//                     //       child: child,
//                     //     );
//                     //   },
//                     //   itemBuilder: (context, item, isSelected) {
//                     //     return Padding(
//                     //       padding: EdgeInsets.symmetric(
//                     //           vertical: height * 0.006,
//                     //           horizontal: width * 0.025),
//                     //       child: Container(
//                     //         height: height * 0.025,
//                     //         color: containercolor,
//                     //         child: Row(
//                     //           children: [
//                     //             dropdownicon != null
//                     //                 ? dropdownicon!
//                     //                 : const SizedBox.shrink(),
//                     //             dropdownsuffix != null
//                     //                 ? Expanded(
//                     //                     child: Text(
//                     //                       item!,
//                     //                       style: ptSansTextStyle(
//                     //                           color: AppColors.black
//                     //                               .withOpacity(0.8),
//                     //                           fontSize: height * 0.02,
//                     //                           fontWeight: FontWeight.w600),
//                     //                     ),
//                     //                   )
//                     //                 : Text(
//                     //                     item!,
//                     //                     style: ptSansTextStyle(
//                     //                         color: AppColors.black
//                     //                             .withOpacity(0.8),
//                     //                         fontSize: height * 0.02,
//                     //                         fontWeight: FontWeight.w600),
//                     //                   ),
//                     //             dropdownsuffix != null
//                     //                 ? dropdownsuffix!
//                     //                 : const SizedBox.shrink(),
//                     //           ],
//                     //         ),
//                     //       ),
//                     //     );
//                     //   },
//                     //   constraints: BoxConstraints.tightFor(),
//                     // ),
//                     popupProps:   popupProps.,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }
//
//   Widget _style(BuildContext context, List<String>? selectedItem) {
//     final h = MediaQuery.of(context).size.height;
//     final w = MediaQuery.of(context).size.width;
//     return Padding(
//       padding: EdgeInsets.only(left: w * 0.02),
//       child: Text(
//         "sds",
//         style: ptSansTextStyle(
//             color: AppColors.black.withOpacity(0.8),
//             fontSize: w * 0.04,
//             fontWeight: FontWeight.w700),
//       ),
//     );
//   }
//
//   Widget _style1(BuildContext context, String? item, bool isSelected) {
//     final height = MediaQuery.of(context).size.height;
//     final width = MediaQuery.of(context).size.width;
//     return Container(
//       height: height * 0.025,
//       child: Row(
//         children: [
//           Icon(Icons.location_on),
//           Text(
//             selectedItem!,
//             style: ptSansTextStyle(
//                 color: AppColors.black.withOpacity(0.8),
//                 fontSize: height * 0.02,
//                 fontWeight: FontWeight.w700),
//           ),
//         ],
//       ),
//     );
//   }
// }