import 'package:flutter/material.dart';

class Globals {
  Globals._();

  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey();
  static final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();
}
