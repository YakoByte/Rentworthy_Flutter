class ApiConfig {
  ApiConfig._();

  static const String scheme = "https://";
  static const String host = "abc.com";
  static const String basePath = "/abc/api/";
  static const String mainurl = scheme + host + basePath;
}
